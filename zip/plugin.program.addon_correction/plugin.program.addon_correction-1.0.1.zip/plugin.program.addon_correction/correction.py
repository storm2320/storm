#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcaddon
import sys,os
import zipfile

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path').decode('utf-8')

sys.path.append(os.path.join(addon_path,'resources','lib').decode('utf-8'))
from elementtree import ElementTree

kodi_addons_path = os.path.join(xbmc.translatePath('special://home'),'addons').decode('utf-8')

def get_addon(addon_dir):

    addon_correction_list = 'Addon rename list :' + '\n'

    try:
        if os.path.isdir(addon_dir):

            xml_path = os.path.join(addon_dir,'addon.xml')

            if os.path.isfile(xml_path):

                tree = ElementTree.parse(r'' + xml_path)
                root = tree.getroot()

                if root :
                    if not str(os.path.dirname(addon_dir)) == str(root.attrib['id']) :

                        try:
                            rename_addon_name = str(os.path.basename(addon_dir)) + ' < = > ' + str(root.attrib['id'])
                            os.rename(addon_dir,os.path.join(os.path.dirname(addon_dir),root.attrib['id']))
                            addon_correction_list += rename_addon_name +'\n'
                        except Exception, e:
                            xbmcgui.Dialog().ok('Addon folder rename error !', rename_addon_name + '\n' + str(e))
                            sys.exit(1)

        return addon_correction_list

    except Exception, e:
        xbmcgui.Dialog().ok('ElementTree error !', str(e))
        sys.exit(1)

def get_addons(addons_dir):

    addon_correction_list = 'Addon rename list :' + '\n'

    try:
        if os.path.isdir(addons_dir):
            objects = os.listdir(addons_dir)

            for objectname in objects:
                if os.path.isdir(os.path.join(addons_dir,objectname)):

                    xml_path = os.path.join(addons_dir,objectname,'addon.xml')

                    if os.path.isfile(xml_path):

                        tree = ElementTree.parse(r'' + xml_path)
                        root = tree.getroot()

                        if root :
                            if not str(objectname) == str(root.attrib['id']) :

                                try:
                                    rename_addon_name = str(objectname) + ' < = > ' + str(root.attrib['id'])
                                    os.rename(os.path.join(addons_dir,objectname),os.path.join(addons_dir,root.attrib['id']))
                                    addon_correction_list += rename_addon_name +'\n'
                                except Exception, e:
                                    xbmcgui.Dialog().ok('Addon folder rename error !', rename_addon_name + '\n' + str(e))
                                    sys.exit(1)

        return addon_correction_list

    except Exception, e:
        xbmcgui.Dialog().ok('ElementTree error !', str(e))
        sys.exit(1)

def get_kodi_addons(addons_dir):

    addon_correction_list = 'Addon rename list :' + '\n'

    try:

        if os.path.isdir(addons_dir):
            objects = os.listdir(addons_dir)

            for objectname in objects:
                if os.path.isdir(os.path.join(addons_dir,objectname)):

                    xml_path = os.path.join(addons_dir,objectname,'addon.xml')

                    if os.path.isfile(xml_path):

                        tree = ElementTree.parse(r'' + xml_path)
                        root = tree.getroot()

                        if root :
                            if not str(objectname) == str(root.attrib['id']) :

                                try:
                                    rename_addon_name = str(objectname) + ' < = > ' + str(root.attrib['id'])
                                    os.rename(os.path.join(addons_dir,objectname),os.path.join(addons_dir,root.attrib['id']))
                                    addon_correction_list += rename_addon_name +'\n'
                                except Exception, e:
                                    xbmcgui.Dialog().ok('Addon folder rename error !', rename_addon_name + '\n' + str(e))
                                    sys.exit(1)

        return addon_correction_list

    except Exception, e:
        xbmcgui.Dialog().ok('ElementTree error !', str(e))
        sys.exit(1)

def input_path_addon():
    input_path_browser =''
    input_path_browser = xbmcgui.Dialog().browse(3,'Eingabe Pfad ?','files', '', False, False).decode('utf-8')
    if input_path_browser == '':
        sys.exit(0)
    if not os.path.exists(input_path_browser) and not os.path.isdir(input_path_browser):
        sys.exit(0)
    return input_path_browser

def input_path_folder():
    input_path_browser =''
    if str(addon.getSetting('remote_path_off_on')) == 'false':
        input_path_browser = xbmcgui.Dialog().browse(3,'Eingabe Pfad ?','files', '', False, False).decode('utf-8')
        if input_path_browser == '':
            sys.exit(0)
    else:
        input_path_browser = str(addon.getSetting('remote_path')).decode('utf-8')
        if not os.path.exists(input_path_browser) and not os.path.isdir(input_path_browser):
            sys.exit(0)
    return input_path_browser
	
def update_kodi_addons():
    xbmc.executebuiltin("UpdateAddonRepos")
    xbmc.executebuiltin("UpdateLocalAddons")

call = xbmcgui.Dialog().select('Kodi Addon Name Korrektur', ['[COLOR lime]Ein Addon ![/COLOR]' , '[COLOR lime]Alle Addons ![/COLOR]' , '[COLOR lime]Alle Kodi Addons ![/COLOR]' , '[COLOR lime]Update alle localen Kodi 16.1 Addons ![/COLOR]'])
if call == -1:
    sys.exit(0)

if call == 0:
    input_path_browser = input_path_addon()
    s_output = get_addon(os.path.abspath(input_path_browser))
    xbmcgui.Dialog().textviewer('Fertig !',s_output)

if call == 1:
    input_path_browser = input_path_folder()
    s_output = get_addons(input_path_browser)
    xbmcgui.Dialog().textviewer('Fertig !',s_output)

if call == 2:
    s_output = get_kodi_addons(kodi_addons_path)
    update_kodi_addons()
    xbmcgui.Dialog().textviewer('Fertig !',s_output)

if call == 3:	
    update_kodi_addons()
#Created by Andre Albus - Loki1979