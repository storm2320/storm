script.module.urllib3
=====================

Python urllib3 library packed for KODI.

See https://github.com/shazow/urllib3
