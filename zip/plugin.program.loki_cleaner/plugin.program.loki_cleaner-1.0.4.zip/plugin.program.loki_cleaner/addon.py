#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcaddon,os,sys,shutil
addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path').decode('utf-8')
home_path = xbmc.translatePath('special://home').decode('utf-8')
addons_path = os.path.join(home_path,'addons').decode('utf-8')
addon_data_path = os.path.join(home_path,'userdata','addon_data').decode('utf-8')
thumbnails_path = os.path.join(home_path,'userdata','Thumbnails').decode('utf-8')
temp_path = os.path.join(home_path,'temp').decode('utf-8')
packages_path = os.path.join(home_path,'addons/packages').decode('utf-8')
sys.path.append(os.path.join(addon_path,'resources','lib').decode('utf-8'))
from elementtree import ElementTree
def get_directory_size(directory):
    dir_size = 0
    if os.path.isdir(directory):
        for (path, dirs, files) in os.walk(directory):
            for file in files:
                filename = os.path.join(path, file)
                if os.path.isfile(filename):
                    dir_size += os.path.getsize(filename)
    return dir_size
def delete_dir(dir_path):
    if os.path.isdir(dir_path):
        shutil.rmtree(dir_path,ignore_errors=True)
def get_addons_import(addons_dir):
    addon_import_array=[]
    if os.path.isdir(addons_dir):
        objects = os.listdir(addons_dir)
        for objectname in objects:
            if os.path.isdir(os.path.join(addons_dir,objectname)):
                xml_path = os.path.join(addons_dir,objectname,'addon.xml')
                if os.path.isfile(xml_path):
                    tree = ElementTree.parse(r'' + xml_path)
                    doc = tree.getroot()
                    if doc :
                        requires = doc.find('requires')
                        if requires :
                            for elem in requires.findall('import'):
                                if not str(elem.get('addon')) in addon_import_array:
                                    addon_import_array.append(str(elem.get('addon')))
    return addon_import_array
def get_addons_dir(addons_dir):
    addons_array=[]
    if os.path.isdir(addons_dir):
        objects = os.listdir(addons_dir)
        for objectname in objects:
            if os.path.isdir(os.path.join(addons_dir,objectname)):
                addons_array.append(str(os.path.join(addons_dir,objectname)))
    return addons_array
def get_addon_data_dir(addon_data_dir):
    addon_data_array=[]
    if os.path.isdir(addon_data_dir):
        objects = os.listdir(addon_data_dir)
        for objectname in objects:
            if os.path.isdir(os.path.join(addon_data_dir,objectname)):
                addon_data_array.append(str(os.path.join(addon_data_dir,objectname)))
    return addon_data_array
def get_old_addons(addons_dir):
    old_addons_list = ''
    if os.path.isdir(addons_dir):
        compare_array=[]
        for s in get_addons_import(addons_dir):
            compare_array.append(str(os.path.basename(s)))
        for addon_item in get_addons_dir(addons_dir):
            addon_name = str(os.path.basename(addon_item))
            if not addon_name in compare_array:
                if not'plugin' in addon_name and not 'repository' in addon_name and not 'repo' in addon_name and not'script' in addon_name and not 'pvr' in addon_name and not 'skin' in addon_name and not 'weather' in addon_name and not 'resource' in addon_name :
                    old_addons_list += addon_name +'\n'
                    delete_dir(addon_item)
                elif 'script.module' in addon_name :
                    old_addons_list += addon_name +'\n'
                    delete_dir(addon_item)
    return old_addons_list
def get_old_addon_data(addons_dir,addon_data_dir):
    old_addon_data_list = ''
    if os.path.isdir(addons_dir) and os.path.isdir(addon_data_dir):
        compare_array=[]
        for s in get_addons_dir(addons_dir):
            compare_array.append(str(os.path.basename(s)))   
        for addon_item in get_addon_data_dir(addon_data_dir):
            addon_name = str(os.path.basename(addon_item))
            if not addon_name in compare_array:
                if not 'pvr' in addon_name and not 'peripheral.joystick' in addon_name and  not 'skin.estuary' in addon_name and not 'skin.estouchy' in addon_name and not 'skin.confluence' in addon_name and not 'skin.re-touched' in addon_name :
                    old_addon_data_list += addon_name +'\n'
                    delete_dir(addon_item)
    return old_addon_data_list
s0 = 'Total Size = ' + str(get_directory_size(home_path)/1024/1024) + 'MB'
s1 = 'Temp Size = ' + str(get_directory_size(temp_path)/1024/1024) + 'MB'
s2 = 'Packages Size = ' + str(get_directory_size(packages_path)/1024/1024) + 'MB' + '\n'	
delete_dir(temp_path)
delete_dir(packages_path)
s3 = 'Temp Size Clean= ' + str(get_directory_size(temp_path)/1024/1024) + 'MB'
s4 = 'Packages Size Clean = ' + str(get_directory_size(packages_path)/1024/1024) + 'MB' + '\n'
s5 = get_old_addons(addons_path)
s6 = get_old_addon_data(addons_path,addon_data_path)
s7 = 'Total Size Clean = ' + str(get_directory_size(home_path)/1024/1024) + 'MB'
xbmcgui.Dialog().textviewer('LOKI1979 CLEANER REPORT',s0 +'\n' + s1 +'\n' + s2 +'\n'  + s7 +'\n' + s3 +'\n' + s4 +'\n' + '[[ Old deleted imports ]]' +'\n' + s5 +'\n' + '[[ Old deleted addon settings ]]' +'\n' + s6 )
if xbmcgui.Dialog().yesno('Delete Thumbnails','Delete thumbnails and "manually restart" Kodi !','','','Exit','Delete') == 1:
    delete_dir(thumbnails_path)
#Created by Loki1979 - 17.12.2016 - 11:21